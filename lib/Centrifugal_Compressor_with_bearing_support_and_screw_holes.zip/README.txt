                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2882438
Centrifugal Compressor with bearing support and screw holes by psaintmalo is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Centrifugal Compressor with support for a bearing to reduce noise and increase stability at high rpm's.

Also it comes with holes to avoid the use of glue so its easier to unmount/mount. It is still possible to mount it without screws, just use some tipe of plastic glue to hold it together.

Needed:
-608 Bearing. (AKA skateboard bearing)
-10 2.9mm Screws (This may vay depending on the model size)

-All of above are recommended but not compulsory.  The design will still work with out the bearing and the screws(in this case you nees to glue it toghether.-

# Print Settings

Printer Brand: Prusa
Printer: Prusa Mk2
Rafts: Doesn't Matter
Supports: Yes

# Post-Printing

## How to assemble the print.

You need to be careful when screwing the motor holder to SK1, the little line on the motor holder should be looking into the print and be at the screwhole which is at the top of the print(The top being the nose where air comes out). This will keep the motor holder centered.